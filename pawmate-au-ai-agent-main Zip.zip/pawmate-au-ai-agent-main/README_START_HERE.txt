PAWMATE AU AI AGENT – START HERE

This ZIP contains everything needed to deploy your AI Agent on Render.

STEPS:
1. Create Render account
2. New → Web Service → Deploy from a folder
3. Upload this ZIP
4. Build command: npm install
5. Start command: npm run start-agent
6. Add environment variables (API keys)
7. Create PostgreSQL database
8. Create Cron Job (hourly)

You do NOT need GitHub.
