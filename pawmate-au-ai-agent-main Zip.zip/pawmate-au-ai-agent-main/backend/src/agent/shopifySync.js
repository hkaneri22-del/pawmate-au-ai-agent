console.log("🛍 ShopifySync module loaded");

async function sync() {
  console.log("🔄 Shopify sync running...");
}

module.exports = {
  sync
};
