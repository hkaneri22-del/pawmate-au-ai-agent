console.log("PawMate AU AI Agent is running...");
require('dotenv').config();

setInterval(() => {
  console.log("AU Agent heartbeat – checking ads, orders & scaling decisions...");
}, 60000);
